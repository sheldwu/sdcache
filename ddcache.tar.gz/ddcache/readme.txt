change to dir server
make
run ddcache and there will be a parameter instruction
